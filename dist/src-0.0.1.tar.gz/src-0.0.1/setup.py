from setuptools import setup,find_packages

setup(
    name="src", 
    version="0.0.1", 
    description="it is a wine Q package",
    author="sv",
    packages=find_packages(),
    linces="MIT"
    )

